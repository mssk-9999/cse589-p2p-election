startup:
./p2p-1.0 3

NOTE: tcp port and udp port are not necessary, program will generate random port number.



11/30/2011
weixian zhou, 5002 6584
